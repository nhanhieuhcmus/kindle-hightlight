# Security Policy

## Supported Versions

Only the latest major/minor versions are supported with security updates.

## Reporting a Vulnerability

Please contact lukas.hollaender@yworks.com before creating a public issue
on GitHub. If I don't respond within two working days and it is urgent,
you may also contact james@parall.ax.
